package ar.primeraactividad.java.actividad;

public class AutoClasico extends Vehiculo {
    public AutoClasico(String marca, String color, String modelo) {
        super(color, marca, modelo);
    }
    
    @Override
    public String getTipo() {
        return "Hola!! soy un Auto Clásico";
    }
}