package ar.primeraactividad.java.actividad;

public class AutoNuevo extends Vehiculo {
    public AutoNuevo(String marca, String color, String modelo, Radio radio) {
        super(color, marca, modelo);
        this.agregarRadio(radio); // Siempre tiene radio
    }

    @Override
    public String getTipo() {
        return "Hola!! soy un Auto Nuevo";
    }
}