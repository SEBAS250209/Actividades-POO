package ar.primeraactividad.java.actividad;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter


public class Radio {
    private String marca;
    private int potencia;
    private Vehiculo vehiculo;

    
    public Radio(String marca, int potencia) {
        this.marca = marca;
        this.potencia = potencia;
    }

    
}