package ar.primeraactividad.test;

import ar.primeraactividad.java.actividad.AutoClasico;
import ar.primeraactividad.java.actividad.AutoNuevo;
import ar.primeraactividad.java.actividad.Colectivo;
import ar.primeraactividad.java.actividad.Radio;

public class TestVehiculos {
    public static void main(String[] args) {
        
    Radio radio1 = new Radio("Sony", 50);
    Radio radio2 = new Radio("JVC", 60);
    Radio radio3 = new Radio("Pioneer", 70);
    

    // autonuevo
    System.out.println("#####################################################################");

    AutoNuevo autonuevo1 = new AutoNuevo("Ford", "verde", " Mustang GT", radio1);

    System.out.println(autonuevo1.getTipo());
    autonuevo1.cambiarRadio(radio2);
    System.out.println(autonuevo1);
    autonuevo1.quitarRadio();
    System.out.println(autonuevo1);
    
  

    
    // autoclasico
    System.out.println("#####################################################################");

    AutoClasico autoClasico1 = new AutoClasico("Chevrolet", " Rojo brillante", "Chevrolet Impala 1964");
    
    System.out.println(autoClasico1.getTipo());
    autoClasico1.agregarRadio(radio1);
    System.out.println(autoClasico1);
    autoClasico1.quitarRadio();
    System.out.println(autoClasico1);
    autoClasico1.cambiarRadio(radio3);
   


    //colectivo
    System.out.println("#####################################################################");

    Colectivo colectivo26 = new Colectivo("Mercedes-Benz", " azul y rojo", "Mercedes-Benz OH1621L");

    System.out.println(colectivo26.getTipo());
    System.out.println(colectivo26);
    colectivo26.agregarRadio(radio3);
    System.out.println(colectivo26);
    colectivo26.cambiarRadio(radio2);
    System.out.println(colectivo26);
    colectivo26.agregarRadio(radio3);
    colectivo26.setPrecio(3000000.0);
    System.out.println(colectivo26);
    


    



    }
}
