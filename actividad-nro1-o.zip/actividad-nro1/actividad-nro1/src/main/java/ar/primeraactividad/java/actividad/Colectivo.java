package ar.primeraactividad.java.actividad;

public final class Colectivo extends Vehiculo {
    public Colectivo(String marca, String color, String modelo) {
        super(color, marca, modelo);
    }

    @Override
    public String getTipo() {
        return "Hola!! soy un Colectivo";
    }
}