package ar.primeraactividad.java.actividad;


import lombok.Getter;
import lombok.Setter;


@Getter
@Setter


public abstract class Vehiculo{
    private String marca;
    private String modelo;
    private String color;
    private Double precio;
    private Radio radio;


    public Vehiculo(String marca, String color, String modelo){ 
        
        this.marca = marca;
        this.color = color;
        this.modelo = modelo;   
    }

     /**
     * Agrega una radio al vehículo si no tiene una ya, si tiene una radio 
     * lo informa.
     * @param nuevaRadio 
     */
    public void agregarRadio(Radio nuevaRadio) {
        if (this.radio == null) {
            this.radio = nuevaRadio;
            nuevaRadio.setVehiculo(this);
        } else {
            System.out.println("El vehículo ya tiene una radio asignada.");
        }
    }
    
    /**
     * Cambia la radio del vehículo, removiendo la actual si existe.
     * También desvincula la radio nueva de cualquier vehículo anterior.
     * @param nuevaRadio 
     */
    public void cambiarRadio(Radio nuevaRadio) {
        if (nuevaRadio != null && nuevaRadio.getVehiculo() != null) {
            nuevaRadio.getVehiculo().radio = null;
        }
    
        if (this.radio != null) {
            this.radio.setVehiculo(null);
        }
    
        this.radio = nuevaRadio;
        nuevaRadio.setVehiculo(this);
    }
   
    /*
     * Quita la radio del vehiculo 
     */
    public void quitarRadio() {
        if (this.radio != null) {
            this.radio.setVehiculo(null);
            this.radio = null;
        }
    }

   

    public abstract String getTipo();

    public String toString() {
        return   marca + " " + modelo + " (" + color + ")" +
        (radio != null ? " / Radio: " + radio.getMarca() + " (" + radio.getPotencia() + "W)" : " | Sin radio") + (precio != null ? " | Precio: $" + precio : ""); 
    }
}
