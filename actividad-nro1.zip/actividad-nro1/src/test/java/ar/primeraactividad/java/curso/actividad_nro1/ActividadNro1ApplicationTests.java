package ar.primeraactividad.java.curso.actividad_nro1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActividadNro1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
